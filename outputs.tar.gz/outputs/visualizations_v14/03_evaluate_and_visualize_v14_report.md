# Res-SAM v14 评估报告

## 数据映射说明
- 论文参考结果：论文 Table 2 参考结果（仅作论文外部对照）
- 本地评估数据：augmented_intact + augmented_cavities + augmented_utilities
- 类别映射：cavities -> cavities，utilities -> pipes/utilities，normal_auc -> augmented_intact
- 扩展指标：Region-level AUC 以预测框为样本、IoU>0.5 为正负标签、框分数为 anomaly_score
- 备注：当前评估固定使用 augmented_intact + augmented_cavities + augmented_utilities。论文数值仅作外部参考，不视为同数据集直接对齐。

## 全自动模式对比

| 指标 | 论文 | 本地 | 差值 |
|---|---:|---:|---:|
| Precision | 0.842 | 0.020 | -0.822 |
| Recall | 0.877 | 0.017 | -0.860 |
| F1 | 0.859 | 0.018 | -0.841 |
| AUC | 0.832 | 0.881 | +0.049 |

## 检测统计
- TP：1
- FP：50
- FN：59
- Precision：0.020
- Recall：0.017
- F1：0.018
- Region-level AUC：0.020000000000000018
- Region-level AUC 样本数：51
- **图像级AUC（论文Table 2口径）：0.8808333333333334**
- 图像级AUC 样本数：90（正类=60 负类=30）
- Region 级粗筛剔除数：35

## 分类别汇总

| 类别 | TP | FP | FN | Precision | Recall | F1 | 粗筛剔除数 |
|---|---:|---:|---:|---:|---:|---:|---:|
| cavities | 0 | 27 | 30 | 0.000 | 0.000 | 0.000 | 25 |
| utilities | 1 | 23 | 29 | 0.042 | 0.033 | 0.037 | 10 |
| normal_auc | 0 | 0 | 0 | 0.000 | 0.000 | 0.000 | 0 |

*生成时间：2026-04-15 02:12:15*